

<?php if(session()->has('message')): ?>
    <div class="alert alert alert-border-bottom alert-system bg-gradient alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <i class="fa fa-check pr10"></i>
        <strong>Éxito!</strong> 
        <a href="#" class="alert-link"><?php echo e(session()->get('message')); ?></a>
    </div>
<?php elseif(session()->has('info_message')): ?>
    <div class="alert alert alert-border-bottom alert-info bg-gradient alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <i class="fa fa-info pr10"></i>
        <strong>Información!</strong> 
        <a href="#" class="alert-link"><?php echo e(session()->get('info_message')); ?></a>
    </div>
<?php elseif(session()->has('alert_config')): ?>
    <div class="alert alert-border-bottom alert-custom bg-gradient alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <i class="fa fa-info pr10"></i>
        <strong>Información!</strong>
        <a href="#" class="alert-link"><?php echo e(session()->get('alert_config')); ?></a>
    </div>
<?php elseif(session()->has('error_message')): ?>
    <div class="alert alert alert-border-bottom alert-danger bg-gradient alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <i class="fa fa-info pr10"></i>
        <strong>Alerta!</strong> 
        <a href="#" class="alert-link"><?php echo e(session()->get('error_message')); ?></a>
    </div>
<?php elseif(session()->has('warning_message')): ?>
    <div class="alert alert alert-border-bottom alert-warning bg-gradient alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <i class="fa fa-info pr10"></i>
        <strong>Advertencia!</strong> 
        <a href="#" class="alert-link"><?php echo e(session()->get('warning_message')); ?></a>
    </div>
<?php elseif($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-sm alert-border-left alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <i class="fa fa-warning pr10"></i>
            <strong>Error!</strong> 
            <a href="#" class="alert-link"><?php echo e($error); ?></a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\crud_laravel\resources\views/layouts/messages/message.blade.php ENDPATH**/ ?>