<!--<script type="text/javascript" src="<?php echo e(asset('js/jvalidation/validate.min.js')); ?>"></script>-->
<script type="text/javascript" src="<?php echo e(asset('js/jvalidation/core.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jvalidation/additional-methods.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jvalidation/messages_es_PE.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jvalidation/methods_es_CL.js')); ?>"></script>

<!-- Validation JS-->
<script type="text/javascript" src="<?php echo e(asset('js/jvalidation/validation.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\crud_laravel\resources\views/scripts-group/jquery-validation.blade.php ENDPATH**/ ?>