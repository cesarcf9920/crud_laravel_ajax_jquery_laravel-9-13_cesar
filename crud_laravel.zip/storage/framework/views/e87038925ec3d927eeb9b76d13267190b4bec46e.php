<!DOCTYPE html>
<html lang="es">

<head>   

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Admin Forms CSS -->
    <link rel="stylesheet" type="text/css"
          href="<?php echo e(asset('bower_components/assets/admin-tools/admin-forms/css/admin-forms.min.css')); ?>">

    <!-- Theme CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('bower_components/assets/skin/default_skin/css/theme.css')); ?>">

    <!-- JsTree CSS -->
    <!--<link rel="stylesheet" href="<?php echo e(asset('bower_components/vendor/plugins/jstree/themes/default/style.min.css')); ?>"/>-->

    <!-- General CSS -->
    <link href="<?php echo e(asset('app/css/styles.css')); ?>" rel="stylesheet" type="text/css"/>

</head>

<body class="dashboard-page onload-check" style="min-height: 1230px; overflow-x: initial;">

<!-- Start: Main -->
<div id="main">
   
    <!-- Start: Header -->
    <header class="navbar navbar-fixed-top navbar-shadow" style="border-top: 5px solid rgb(244, 123, 34); height: 65px">
        <!--bg-hitachi-->
        <div class="navbar-branding dark">

            <a class="navbar-brand" href="<?php echo e(route('usuario.index')); ?>" style="padding-left: 0px;">
               
            </a>
            <a class="navbar-brand" href="#" style="font-size: 11px; margin-top: 14px; padding-left: 0;">
                
            </a>
            <span id="toggle_sidemenu_l" class="ad ad-lines"></span>
        </div>
        <?php echo $__env->make('layouts.navs.nav-left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>
    <!-- End: Header -->

    <!-- Start: Sidebar Left -->
    <aside id="sidebar_left" class="nano nano-light affix has-scrollbar sidebar-light light">
        <!-- Start: Sidebar Left Content -->
        <div class="sidebar-left-content nano-content" tabindex="0">
            <div class="nav-collapse">
                <?php echo $__env->make('layouts.sidebars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <!-- End: Sidebar Left Content -->

        <div class="nano-panel">
            <div class="nano-slider" style="height: 336px; transform: translate(0px, 0px);">
            </div>
        </div>
    </aside>
    <!-- End: Sidebar Left -->

    <!-- Start: Content-Wrapper -->
    <section id="content_wrapper">
        
        <!-- Start: Topbar -->
        <header id="topbar" class="alt">
            <div class="topbar-left">
                <?php echo $__env->yieldContent('breadcrumb'); ?>
            </div>
            <div class="topbar-right">
                <?php echo $__env->yieldContent('topbar'); ?>
            </div>
        </header>
        <!-- End: Topbar -->

        <!-- Begin: Content -->
        <section id="content" class="">            
            <?php echo $__env->yieldContent('content-errors'); ?>
            <div class='side-body'></div>
            <?php echo $__env->make('layouts.messages.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </section>
        <!-- End: Content -->

    </section>
    <!-- End: Content-Wrapper -->

    <!-- Start: Theme Preview Panel -->
    <!-- End: Theme Preview Panel -->
</div>
<!-- End: Main -->
<div class="modal-background"></div>

<!-- JQuery -->
<script type="text/javascript" src="<?php echo e(asset('bower_components/vendor/jquery/jquery-1.11.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('bower_components/vendor/jquery/jquery_ui/jquery-ui.min.js')); ?>"></script>

<!--Config plugins JS-->
<script type="text/javascript" src="<?php echo e(asset('js/config.js')); ?>"></script>

<!--Theme Javascript-->
<script type="text/javascript" src="<?php echo e(asset('bower_components/assets/js/utility/utility.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/functions.js')); ?>"></script>

<!-- Scripts in views -->
<?php echo $__env->yieldPushContent('scripts'); ?>

<!-- BEGIN: PAGE SCRIPTS -->
<script type="text/javascript">
   
    $(document).ready(function () {
        "use strict";
        
        $.ajaxSetup({
            statusCode: {
                200: function () {
                    //                      var top = 0;// $(".side-body:last").offset().top;
                    //                       $("[type=submit]").removeAttr("disabled");
                    //                       $("body").scrollTop(top);
//                        AlertMessage.removeCurrentAlerts();
                }
            }
        });

        $.ajaxSetup({
            statusCode: {
                401: function () {
                    AlertMessage.printError('.side-body:last', 'No tiene permitido realizar esta acción o ver parte de este contenido.');
                    var top = 0;// $(".side-body:last").offset().top;
                    $("[type=submit]").removeAttr("disabled");

                    if ($(".bootbox").length) {
                        $(".modal-body").animate({scrollTop: 0}, "fast");
                    } else {
                        $(document).scrollTop(top);
                    }
                }
            }
        });

        $.ajaxSetup({
            statusCode: {
                403: function (data) {
                    var message = data.responseJSON == '' ? 'No tiene permitido realizar esta acción o ver parte de este conteanido.' : data.responseJSON;
                    AlertMessage.printError('.side-body:last', message);
                    var top = 0;
                    $("[type=submit]").removeAttr("disabled");

                    if ($(".bootbox").length) {
                        $(".modal-body").animate({scrollTop: 0}, "fast");
                    } else {
                        $(document).scrollTop(top);
                    }

                }
            }
        });

        $.ajaxSetup({
            statusCode: {
                404: function (data) {
                    AlertMessage.printInfo('.side-body:last', 'No se encontraron resultados.');
                    var top = 0;
                    $("[type=submit]").removeAttr("disabled");

                    if ($(".bootbox").length) {
                        $(".modal-body").animate({scrollTop: 0}, "fast");
                    } else {
                        $(document).scrollTop(top);
                    }
                }
            }
        });

        $.ajaxSetup({
            statusCode: {
                422: function (data) {
                    AlertMessage.printError('.side-body:last', data.responseJSON.errors);
                    var top = 0;
                    $("[type=submit]").removeAttr("disabled");

                    if ($(".bootbox").length) {
                        $(".modal-body").animate({scrollTop: 0}, "fast");
                    } else {
                        $(document).scrollTop(top);
                    }
                }
            }
        });
        
        $.ajaxSetup({
            statusCode: {
                500: function (data) {
                    AlertMessage.print('.side-body:last', data.responseText);
                    var top = 0;
                    $("[type=submit]").removeAttr("disabled");

                    if ($(".bootbox").length) {
                        $(".modal-body").animate({scrollTop: 0}, "fast");
                    } else {
                        $(document).scrollTop(top);
                    }
                }
            }
        });

    });
</script>
<!-- END: PAGE SCRIPTS -->

</body>
<input type="hidden" value="0" id="valid_ajax_request"/>

</html><?php /**PATH C:\xampp\htdocs\crud_laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>