
<?php $__env->startSection('breadcrumb'); ?>
    <ol class="breadcrumb">
        <li class="crumb-active">
                <a href="<?php echo e(route('usuario.index')); ?>">Lista de Usuarios</a>
        </li>  
        <li class="crumb-icon">
            <a href="<?php echo e(route('usuario.index')); ?>">
                <span class="glyphicon glyphicon-home"></span>
            </a>
        </li>
        <li class="crumb-link">
            <a href="<?php echo e(route('usuario.index')); ?>">Home</a>
        </li>
        <li class="crumb-link">
            <a href="<?php echo e(route('usuario.index')); ?>">Usuarios</a>
        </li>
        <li class="crumb-trail">
            <stronh>Lista de Usuarios</strong>
        </li>        
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topbar'); ?>
<a class="btn btn-success" id="btn-create" href="<?php echo e(route('usuario.create')); ?>">
    <i class="fa fa-plus"></i>
    <b>NUEVO USUARIO</b>
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="theme-primary theme-primary">
    <div class=" center-block"> 
        <div class="content-table">
            <div class="panel">
                <div class="panel-menu p12 theme-primary">
                </div>
                <div class="center-block">  
                    <div id="table-content">
                        
                    </div>
                </div>   
    
            </div>
        </div>
    </div>

    <!-- DELETE FORM -->
    <?php echo Form::open([ 'route' => ['usuario.delete', ':ROW_ID'], 'method' => 'DELETE', 'id' => 'form-delete']); ?>

    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script type="text/javascript">        
        var url_load                = "<?php echo e(route('usuario.load')); ?>";
        var entity_title            = "USUARIO";
    </script>
    
    <!-- Touchspin -->
    <script type="text/javascript" src="<?php echo e(asset('bower_components/vendor/plugins/touchspin/jquery.bootstrap-touchspin.js')); ?>"></script>
    <!-- Bootbox modal + functions(modal, alerts Customized) -->
    <script type="text/javascript" src="<?php echo e(asset('js/bootbox.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/functions.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/filter.js')); ?>"></script>  
     <!-- Bootstrap-datetimepicker Plugin + moment Dependency -->
     <script type="text/javascript" src="<?php echo e(asset('bower_components/vendor/plugins/fullcalender/lib/moment.min.js')); ?>"></script>
     <script type="text/javascript" src="<?php echo e(asset('bower_components/vendor/plugins/datetimepicker/src/bootstrap-datetimepicker.js')); ?>"></script>
    <!-- Select2 v.4 -->
    <script type="text/javascript" src="<?php echo e(asset('bower_components/vendor/plugins/select2v4/dist/js/select2.js')); ?>"></script>  
    <!-- Validations JS -->
    <?php echo $__env->make('scripts-group.jquery-validation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Index JS -->
    <script type="text/javascript" src="<?php echo e(asset('app/usuario/index.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/usuario/index.blade.php ENDPATH**/ ?>