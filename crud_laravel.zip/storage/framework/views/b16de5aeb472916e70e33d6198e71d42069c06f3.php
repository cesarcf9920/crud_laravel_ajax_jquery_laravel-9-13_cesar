
    <form class="navbar-form navbar-left navbar-search alt" role="search">
        <div class="form-group">
           <input type="text" class="form-control" placeholder="Search...">
        </div>
    </form><?php /**PATH C:\xampp\htdocs\crud_laravel\resources\views/layouts/navs/nav-left.blade.php ENDPATH**/ ?>