<div class="row">
    <div class="col-xs-12">
        <div class="card card-no-bottom-line admin-form">
            <div class="side-body"></div>
                <div class="card-body">            
                <?php echo Form::open( ['class' => 'form-horizontal form-modal-left', 'id' => 'form-show' ]); ?>                         
                    <div class="form-group">
                        <label for="name" class="col-sm-4 control-label">Nombre</label>
                        <div class="col-sm-8">
                            <label class="field">
                                <input type="text" class="form-control gui-input" readonly="true" id="name" name="name" placeholder="Nombre" value="<?php echo e($usuario->name); ?>">    
                            </label>                            
                        </div>                                    
                    </div>
                    <div class="form-group">
                        <label for="phone" class="col-sm-4 control-label">Teléfono</label>
                        <div class="col-sm-8">
                            <label class="field">
                                <input type="text" class="form-control gui-input" readonly="true" id="phone" name="phone" placeholder="Teléfono" value="<?php echo e($usuario->phone); ?>">    
                            </label>                            
                        </div>                                    
                    </div>
                    <div class="form-group">
                        <label for="email" class="col-sm-4 control-label">Correo</label>
                        <div class="col-sm-8">
                            <label class="field">
                                <input type="text" class="form-control gui-input" readonly="true" id="email" name="email" placeholder="Correo" value="<?php echo e($usuario->email); ?>">    
                            </label>                            
                        </div>                                    
                    </div>
                    <div class="form-group">
                        <label for="compañia" class="col-sm-4 control-label">Compañia</label>
                        <div class="col-sm-8">
                            <label class="field">
                                <input type="text" class="form-control gui-input only_decimal" readonly="true" id="compañia" name="compañia" placeholder="Compañia" value="<?php echo e($usuario->compañia); ?>">    
                            </label>                            
                        </div>                                    
                    </div>
                    <div class="form-group">
                        <label for="street" class="col-sm-4 control-label">Estado</label>
                        <div class="col-sm-8">
                            <label class="field">
                                <input type="text" class="form-control gui-input only_decimal" readonly="true" id="street" name="street" placeholder="Calle" value="<?php echo e($usuario->street); ?>">    
                            </label>                            
                        </div>                                    
                    </div>
                <?php echo Form::close(); ?>  
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\prueba\resources\views/usuario/modals/show.blade.php ENDPATH**/ ?>