<table class="table table-hover table-striped fs12">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Company</th>
            <th>Calle</th>
            <th>Latitud</th>
            <th>longitud</th>
            <th style="width:150px;max-width: 150px;min-width: 150px;">Opciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($usuario->name); ?></td>
            <td><?php echo e($usuario->phone); ?></td>
            <td><?php echo e($usuario->email); ?></td>
            <td><?php echo e($usuario->compañia); ?></td> 
            <td><?php echo e($usuario->street); ?></td>
            <td><?php echo e($usuario->lat); ?></td> 
            <td><?php echo e($usuario->lng); ?></td> 
            <td>
                <a title="Detalle"  data-name="<?php echo e($usuario->name); ?>" href="<?php echo e(route('usuario.show', $usuario->id)); ?>" class="btn btn-default show-entity  pl10 pr10 btn-show">
                    <i class="fa fa-lg fa-info"></i>
                </a>
                <a title="Editar" data-name="<?php echo e($usuario->name); ?>"  href="<?php echo e(route('usuario.edit', $usuario->id)); ?>" class="btn btn-default edit-entity pl5 pr5 btn-edit">
                    <i class="fa fa-lg fa-pencil"></i>
                </a>
                <a title="Eliminar" data-name="<?php echo e($usuario->name); ?>" data-id="<?php echo e($usuario->id); ?>" href="\#" class="btn btn-danger delete-entity pl5 pr5 btn-delete">
                    <i class="fa fa-lg fa-trash"></i>
                </a>                
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="4" class="text-center text-muted"><span>No se encontraron resultados</span></td>
        </tr>
        <?php endif; ?>
    </tbody>
    <tfoot>
        <tr class="bg-light">
        </tr>
    </tfoot>
</table>
<?php /**PATH C:\xampp\htdocs\crud_laravel\resources\views/usuario/partials/load.blade.php ENDPATH**/ ?>